
#define F_CPU  14746000UL //8000000UL //
#include <avr/io.h>
#include <avr/interrupt.h>
#include "TWI_Master.h"
#include "Struct.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <util/delay.h>
#include <avr/sleep.h>
#include <math.h>
#include <avr/power.h>


#define BUAD	9600   //19200 //
#define BRC		((F_CPU/16UL/BUAD)-1)

#define RX_BUFFER_SIZE 128
char RxBuffer[RX_BUFFER_SIZE];

#define MAX_STR_LEN 20

char InputStr[MAX_STR_LEN];
char input_char;
int  input_str_len=0;

void USARTWriteChar(char data);
int USARTHasData();
void RXTX_Setup(void);
char GetChar(void);
void ClearString(char *str, int len);
void PrintUARTstring(char *str);
void Parse_String(char *str);
void Setup_timer(void);
void Timer_Stop(void);


void INT_PIN_ENABLE(void);
void INT_PIN_DISABLE(void);


volatile uint8_t rxReadpos=0; //sp�r helge om disse kan v�re i struct?
volatile uint8_t rxWritepos=0;


#define FRAM_ADDRESS 0x50
#define ACCEL_ADDRESS 0x18
#define HUMID_ADDRESS 0x40

#define NUM_SYSTEMS 1
TSystem rgSystems[NUM_SYSTEMS];
temp rgUnion[NUM_SYSTEMS];


void Initialize_System(void)
{
	
	rgSystems->Address = FRAM_ADDRESS;
	rgUnion->Write_Address = 0;
	rgSystems->Logging_count=0;
	rgSystems->Logging_Interval = 15;
	rgSystems->year=2019;
	rgSystems->month=1;
	rgSystems->date=1;
	rgSystems->hour=12;
	rgSystems->minute=0;
	rgSystems->second=0;
	rgSystems->Index = 0;
	rgSystems->Accle_Ths=800;
	rgSystems->current_state=Service;
	
}
void Initiate_HTU21D(void) //kan muligens gj�re noen endringer for � spare mer str�m. minimalt!
{
	unsigned char messageBuf[4];
	unsigned char TWI_targetSlaveAddress=HUMID_ADDRESS;
	messageBuf[0] = (TWI_targetSlaveAddress<<TWI_ADR_BITS) | (FALSE<<TWI_READ_BIT); // 0x40<<1|0x00; (SA+write)
	messageBuf[1] =  0xE7;	// E3= Hold master Temp mode. E5=Hold master Humidity
	TWI_Start_Transceiver_With_Data( messageBuf, 2);//sender 2 byte
	messageBuf[0] = (TWI_targetSlaveAddress<<TWI_ADR_BITS) | (TRUE<<TWI_READ_BIT); //0x40<<1|0x01;(SA+read)
	TWI_Start_Transceiver_With_Data( messageBuf, 1);//sender 1 byte
	TWI_Get_Data_From_Transceiver( messageBuf, 4);//leser 3 byte(DATA"MSB",DATA"LSB",Checksum)
	int data= messageBuf[1];
	messageBuf[0] = (TWI_targetSlaveAddress<<TWI_ADR_BITS) | (FALSE<<TWI_READ_BIT); // 0x40<<1|0x00; (SA+write)
	messageBuf[1] =  0xE6;	// E3= Hold master Temp mode. E5=Hold master Humidity
	messageBuf[2] =  0x82;	// E3= Hold master Temp mode. E5=Hold master Humidity
	TWI_Start_Transceiver_With_Data( messageBuf, 3);//sender 2 byte

	
}


int Read_From_HTU21D(int mode)
{
	
	unsigned char messageBuf[4];
	unsigned char TWI_targetSlaveAddress=HUMID_ADDRESS;
	//char value[80];
	float humidity;
	float temperature;
	uint16_t data;
	uint16_t Raw_Humidity;
	uint16_t index_high;
	uint16_t index_low;
	messageBuf[0] = (TWI_targetSlaveAddress<<TWI_ADR_BITS) | (FALSE<<TWI_READ_BIT); // 0x40<<1|0x00; (SA+write)
	messageBuf[1] =  0xE3;	// E3= Hold master Temp mode. E5=Hold master Humidity
	TWI_Start_Transceiver_With_Data( messageBuf, 2);//sender 2 byte
	messageBuf[0] = (TWI_targetSlaveAddress<<TWI_ADR_BITS) | (TRUE<<TWI_READ_BIT); //0x40<<1|0x01;(SA+read)
	messageBuf[1] =  0x00;
	TWI_Start_Transceiver_With_Data( messageBuf, 4 );//sender 1 byte
	TWI_Get_Data_From_Transceiver( messageBuf, 4);//leser 3 byte(DATA"MSB",DATA"LSB",Checksum)
	index_high=messageBuf[1];
	index_low=messageBuf[2];
	data=((index_high<<8)|(index_low));
	temperature=(175.72*((float)data)/65536.0)-46.85;
	temperature=-0.15*(25-temperature);
	messageBuf[0] = (TWI_targetSlaveAddress<<TWI_ADR_BITS) | (FALSE<<TWI_READ_BIT); // 0x40<<1|0x00; (SA+write)
	messageBuf[1] =  mode;	// E3= Hold master Temp mode. E5=Hold master Humidity
	TWI_Start_Transceiver_With_Data( messageBuf, 2);//sender 2 byte
	messageBuf[0] = (TWI_targetSlaveAddress<<TWI_ADR_BITS) | (TRUE<<TWI_READ_BIT); //0x40<<1|0x01;(SA+read)
	messageBuf[1] =  0x00;
	TWI_Start_Transceiver_With_Data( messageBuf, 4 );//sender 1 byte
	TWI_Get_Data_From_Transceiver( messageBuf, 4);//leser 3 byte(DATA"MSB",DATA"LSB",Checksum)
	index_high=messageBuf[1];
	index_low=messageBuf[2];
	data=((index_high<<8)|(index_low));
	if (mode==0xE5)// E5=Hold master Humidity
	{	
		Raw_Humidity = (data & 0xFFFC); // clearing status bits
		double test = (double)Raw_Humidity;
		humidity = -6.0 + 125.0*test/(256.0*256.0);
		humidity += temperature+10;
		int humid = round(humidity);
		if (humid<=5)
		{
			humid=5;
		}
		if (humid>=95)
		{
			humid=95;
		}
		//sprintf(value,"%d",humid);
		//printUARTstring(value);
		//printUARTstring("  % Relative Humidity");
		//printUARTstring("\r\n");
		return humid;
	}
	else if (mode==0xE3)//E3= Hold master Temp mode.
	{
		temperature=(175.72*((float)data)/65536.0)-46.85;
		int temp=round(temperature);
		//sprintf(value,"%d",temp);
		//printUARTstring(value);
		//printUARTstring(" Degrees Celsius");
		//printUARTstring("\r\n");
		return temp;
	}
}


unsigned char TWI_Act_On_Failure_In_Last_Transmission ( unsigned char TWIerrorMsg )
{
                    // A failure has occurred, use TWIerrorMsg to determine the nature of the failure
                    // and take appropriate actions.
                    // Se header file for a list of possible failures messages.
                    
                    // Here is a simple sample, where if received a NACK on the slave address,
                    // then a retransmission will be initiated.
 
  if ( (TWIerrorMsg == TWI_MTX_ADR_NACK) | (TWIerrorMsg == TWI_MRX_ADR_NACK) )
    TWI_Start_Transceiver();
    
  return TWIerrorMsg; 
}

void Accel_I2C_Write(int message,int num_bytes, int data) //skriver til Accelerometeret
{	unsigned char messageBuf[4];
	unsigned char TWI_targetSlaveAddress=ACCEL_ADDRESS;
	messageBuf[0] = (TWI_targetSlaveAddress<<TWI_ADR_BITS) | (FALSE<<TWI_READ_BIT); // 0x40<<1|0x00; (SA+write)
	messageBuf[1] =  message;	// E3= Hold master Temp mode. E5=Hold master Humidity			          
	messageBuf[2] = data;
	TWI_Start_Transceiver_With_Data( messageBuf, num_bytes);//sender bytes
}

int Accel_I2C_Read(int num_bytes)  //leser fra accelerometeret
{	char value[8];
	int ret;
	unsigned char messageBuf[4];
	unsigned char TWI_targetSlaveAddress=ACCEL_ADDRESS;
	messageBuf[0] = (TWI_targetSlaveAddress<<TWI_ADR_BITS) | (TRUE<<TWI_READ_BIT); //0x40<<1|0x01;(SA+read)
	TWI_Start_Transceiver_With_Data( messageBuf, 1 );//sender 1 byte
	TWI_Get_Data_From_Transceiver( messageBuf, num_bytes);
	itoa(messageBuf[1],value,10);
	ret=atoi(value);
	return ret;
}	 

void Initialize_Accel(void) // initialiserer Accelerometeret
{	
	Accel_I2C_Write(0x20,3,0x2F); // Turn on the sensor with ODR = 10Hz normal mode.
	Accel_I2C_Write(0x21,3,0x00);	//tenger ikke filter i f�rste omgang   (kan v�re 00)
	Accel_I2C_Write(0x22,3,0x40);	// ACC AOI1 interrupt signal is routed to INT1 pin. tror denne skal v�re 0x40 

	Accel_I2C_Write(0x23,3,0x10); // 00= Full Scale = +/-2 g with BDU and HR bits enabled. 18=HR +-4g 

	Accel_I2C_Write(0x24,3,0x08);  // Default value. Interrupt signals on INT1 pin is latched. Users need to read the INT1_SRC  register to clear the interrupt signal. 

	
	Accel_I2C_Write(0x32,3,rgSystems->Accle_Ths/32);  // Threshold (THS) = 2LSBs * 16mg = 32mg.

	Accel_I2C_Write(0x33,3,0x00); // Duration = 50LSBs * (1/10Hz) = 0s.

	Accel_I2C_Write(0x30,3,0xEA); //  Enable XLIE, YLIE and ZLIE interrupt generation,=R logic. It means that the interrupt will be generated   when either X , Y or Z axis acceleration is within the   �THS threshold.              

}
void HighRes_Accel(void)
{
Accel_I2C_Write(0x20,3,0xEE); // Turn on the sensor with ODR = 10Hz normal mode.
Accel_I2C_Write(0x23,3,0x18); // Full Scale = +/-4 g with BDU and HR bits enabled.
}
void I2C_Write(int num_bytes,int value) //skriver til F-RAM
{	unsigned char messageBuf[4];
	unsigned char TWI_targetSlaveAddress=FRAM_ADDRESS;
	messageBuf[0] = (TWI_targetSlaveAddress<<TWI_ADR_BITS) | (FALSE<<TWI_READ_BIT); // 0x40<<1|0x00; (SA+write)
	messageBuf[1] =  rgUnion->Write_Bytes[1];	// E3= Hold master Temp mode. E5=Hold master Humidity			          
	messageBuf[2] =	rgUnion->Write_Bytes[0];
	messageBuf[3] = value;
	TWI_Start_Transceiver_With_Data(messageBuf, num_bytes);
}
int I2C_Read(int num_bytes) //leser fra F_RAM
{
	char value[8];
	int ret;
	unsigned char messageBuf[4];
	unsigned char TWI_targetSlaveAddress=FRAM_ADDRESS;
	messageBuf[0] = (TWI_targetSlaveAddress<<TWI_ADR_BITS) | (TRUE<<TWI_READ_BIT); //0x40<<1|0x01;(SA+read)
	TWI_Start_Transceiver_With_Data( messageBuf, 1 );//sender 1 byte
	TWI_Get_Data_From_Transceiver( messageBuf, num_bytes);
	itoa(messageBuf[1],value,10);
	ret=atoi(value);
	return ret;
	
}

void Write_Value_Fram(char *InputStr) //skriver til F-RAM (gj�r om sting til int)
{	 int value;
	sscanf(InputStr,"%*[^0123456789]%d",&value);
	I2C_Write(4,value);
}
void Read_From_Fram(void) //leser fra F_RAM
{	int value;
	char message[10];
	I2C_Write(3,0);
	//I2C_Read(2);
	value=I2C_Read(2);
	itoa(value,message,10);
	PrintUARTstring(message);
	PrintUARTstring("\r\n");
		
}

int Check_Angel(void)
{	//HighRes_Accel();//funksjon for � kj�re opp oppl�sningen p� accelerometer
	double pitch=0;
	double roll=0;
	double sqrt_roll=0;
	double sqrt_pitch=0;
	char arr[6];
	int16_t nXlow = 0;
	int16_t nXhi  = 0;
	int nYlow = 0;
	int nYhi  = 0;
	int nZlow = 0;
	int nZhi  = 0;
	int16_t accx = 0;
	int16_t accy = 0;
	int16_t accz = 0;
	int16_t X;
	int16_t Y;
	int16_t Z;
	double X_d;
	double Y_d;
	double Z_d;
	int num = 0;
	char value[80];
	for (int i = 0;i <= 5;i++)
	{
		num = (0x28+i);
		Accel_I2C_Write(num,2,0);
		arr[i] = Accel_I2C_Read(2);
	}

	nXlow = arr[0];
	nXhi  = arr[1];
	nYlow = arr[2];
	nYhi  = arr[3];
	nZlow = arr[4];
	nZhi  = arr[5];
	accx = ((nXhi << 8) | (nXlow & 0xFF));
	accy = ((nYhi << 8) | (nYlow & 0xFF));
	accz = ((nZhi << 8) | (nZlow & 0xFF));
	X = accx >> 4;
	Y = accy >> 4;
	Z = accz >> 4;
	X_d=(double)X/512.0;
	Y_d=(double)Y/512.0;
	Z_d=(double)Z/512.0;
	sqrt_pitch=(sqrt(Y_d*Y_d+Z_d*Z_d));
	sqrt_roll=(sqrt(X_d*X_d+Z_d*Z_d));
	pitch=atan(X_d/sqrt_pitch)*180/3.1415;
	roll=atan(Y_d/sqrt_roll)*180/3.1415;
	//PrintUARTstring("Pitch=");
	sprintf(value, "%.2f",pitch);
	//PrintUARTstring(value);
	//PrintUARTstring(",");
	sprintf(value, "%.2f", roll);
	//PrintUARTstring(value);
	//PrintUARTstring("\r\n");
	
	PrintUARTstring("X=");
	sprintf(value, "%.2f",X_d);
	PrintUARTstring(value);
	PrintUARTstring(",Y=");
	sprintf(value, "%.2f", Y_d);
	PrintUARTstring(value);
	PrintUARTstring(",Z=");
	sprintf(value, "%.2f",Z_d);
	PrintUARTstring(value);
	PrintUARTstring("\r\n");
	//Initialize_Accel();
	if (pitch>80||pitch<-80||roll>80||roll<-80)
	{
		PrintUARTstring("TILTED!");
		PrintUARTstring("\r\n");
		return 1;
	}
	else
	{
		return 0;
	}
}


void Logg_Mesurement(void)
{
	char value[80];
	int Temperature;
	int Humidity;
	int Accel;
	Humidity=Read_From_HTU21D(0xE5);
	Temperature=Read_From_HTU21D(0xE3);
//	PrintUARTstring("Humidity=");
	sprintf(value, "%d",Humidity);
//	PrintUARTstring(value);
//	PrintUARTstring(",Temperature=");
	sprintf(value, "%d", Temperature);
//	PrintUARTstring(value);
//	PrintUARTstring("\r\n");
	int temp = PIND & 0x08;
	if (temp==0)
	{
		Accel=((Check_Angel()<<7)|0);
		int arr[]={Temperature,Humidity,Accel};
		for (int i=0;i<=2;i++)
		{
			I2C_Write(4,arr[i]);
			rgUnion->Write_Address++;
		}
	}
	else
	{
		Accel_I2C_Write(0x31,2,0);
		Accel = ((Check_Angel()<<7)|Accel_I2C_Read(2));
		int arr[]={Temperature,Humidity,Accel};
		for (int i=0;i<=2;i++)
		{
			I2C_Write(4,arr[i]);
			rgUnion->Write_Address++;
		}
	}
	
}
void Print_Temp_Humid(void)
{
	char value[80];
	int Temperature;
	int Humidity;
	Humidity=Read_From_HTU21D(0xE5);
	Temperature=Read_From_HTU21D(0xE3);
	//PrintUARTstring("Humidity=");
	sprintf(value, "%d",Humidity);
	PrintUARTstring(value);
	PrintUARTstring(",");
	sprintf(value, "%d", Temperature);
	PrintUARTstring(value);
	PrintUARTstring("\r\n");
}

void Set_Date(char *InputStr)
{	uint16_t year;
	int month;
	int date;
	int hour;
	int minutte;
	sscanf(InputStr,"%*[^0123456789]%d,%d,%d,%d,%d",&year,&month,&date,&hour,&minutte);
	rgSystems->year = year;
	rgSystems->month = month;
	rgSystems->date = date;
	rgSystems->hour = hour;
	rgSystems->minute = minutte;
}

void Update_Index(void)
{	
	uint16_t Index_Low= rgUnion->Write_Bytes[0];
	uint16_t Index_High= rgUnion->Write_Bytes[1];
	rgUnion->Write_Address=0x0A;
	int arr[2]={Index_Low,Index_High};
	for (int i=0;i<=1;i++)
	{
		I2C_Write(4,arr[i]);
		rgUnion->Write_Address++;
	}
	rgUnion->Write_Address=(Index_High<<8)|Index_Low;
}
void Update_Intervall_Count(void)
{	uint16_t Hold_Pos= rgUnion->Write_Address;
	rgUnion->Write_Address=0x08;
	int count_high=(rgSystems->Logging_count>>8);
	int count_low= rgSystems->Logging_count&0xFF;
	int arr[2]={count_low,count_high};
	for (int i=0;i<=1;i++)
	{
		I2C_Write(4,arr[i]);
		rgUnion->Write_Address++;
	}
	rgUnion->Write_Address=Hold_Pos;
}
void Clear_Data(void)
{	int FF = 255;
	rgUnion->Write_Address=0x10;
	for (uint16_t j = 0x0010; j <= 0x7FFE;j++) //max=0x7FFF
		{
			I2C_Write(4,FF);
			rgUnion->Write_Address++;
		}
	rgUnion->Write_Address=0x08;
	for (int i=0;i<=3;i++)
	{
		I2C_Write(4,0);
		rgUnion->Write_Address++;
	}
	rgSystems->Index=0;
	rgSystems->Logging_count=0;
	rgUnion->Write_Address=0x10;
	
}
void Set_Default_Settings(void)
{
	int arr[16]={1,0xE3,0x07,1,1,12,0,15,0,0,0x10,0,1}; // initiated,2019(L),2019(H),jan,first,kl12,etc
	rgUnion->Write_Address=0;
	for (int i=0;i<=0x0F;i++)
	{
		I2C_Write(4,arr[i]);
		rgUnion->Write_Address++;
	}
}
void Initiate_Logger(void) //for � sette opp setings og cleare memeroy
{	uint16_t count = 0;		
	int Low_count = count & 0xff; //dette er un�dvendig
	int High_count=count>>8;		//dette er un�dvendig
	int year_high=rgSystems->year>>8;
	int year_low=rgSystems->year&0xFF;
	int arr[16]={rgSystems->initialzed,year_low,year_high,rgSystems->month,rgSystems->date,rgSystems->hour,rgSystems->minute,rgSystems->Logging_Interval
	,Low_count,High_count,rgUnion->Write_Bytes[0],rgUnion->Write_Bytes[1],rgSystems->Logging_Mode};
	rgUnion->Write_Address=0;
	for (int i=0;i<=0x0F;i++)
	{
		I2C_Write(4,arr[i]);
		rgUnion->Write_Address++;
	}
	for(int j=0; j<=1;j++)
	{
		Accel_I2C_Write(0x31,2,0); //resetter Accelerometer
		Accel_I2C_Read(2);
	}
}

int Check_Initialized_System(void)
{	int init=0;
	rgUnion->Write_Address=0;
	I2C_Write(3,0);
	init=I2C_Read(2);
	return init;
}

uint16_t Check_Logg_Count(void)
{
	int arr[2];
	uint16_t count=0;
	rgUnion->Write_Address=0x08; 
	for (int i=0; i<=1;i++)
	{	//PrintUARTstring("IntervalCount 1/2=");
		I2C_Write(3,0);	
		arr[i]=I2C_Read(2);
		rgUnion->Write_Address++;
	}
	count=(arr[1]<<8)|arr[0];
	char message[20];
	itoa(count,message,10);
	PrintUARTstring(message);
	PrintUARTstring("\r\n");
	return count;
	
}
void Check_Start_Time(void)
{
	int arr[2];
	int time;
	uint16_t year=0;
	rgUnion->Write_Address=0x01; 
	for (int i=0; i<=1;i++)
	{	
		I2C_Write(3,0);	
		arr[i]=I2C_Read(2);
		rgUnion->Write_Address++;
	}
	year=(arr[1]<<8)|arr[0];
	char message[20];
	itoa(year,message,10);
	PrintUARTstring(message);
	PrintUARTstring("\r\n");
	for (int i=0; i<=4;i++)
	{	
		I2C_Write(3,0);	
		time=I2C_Read(2);
		itoa(time,message,10);
		PrintUARTstring(message);
		PrintUARTstring("\r\n");
		rgUnion->Write_Address++;
	}
	
}
void Read_Settings(void)
{	rgUnion->Write_Address=0;
	char message[20];
	int settings;
	for (int i=0; i<0x10;i++)
	{
		I2C_Write(3,0);
		settings=I2C_Read(2);
		itoa(settings,message,10);
		PrintUARTstring(message);
		PrintUARTstring("\r\n");
		rgUnion->Write_Address++;
	}
}
void Set_Ths(char *InputStr)
{
	int Threshold;
	sscanf(InputStr,"%*[^0123456789]%d",&Threshold);
	rgSystems->Accle_Ths=Threshold;
	PrintUARTstring("200 OK\r\n");
}
void Get_XYZ(void)
{	char arr[6];
	int16_t nXlow = 0;
	int16_t nXhi  = 0;
	int nYlow = 0;
	int nYhi  = 0;
	int nZlow = 0;
	int nZhi  = 0;
	int16_t accx = 0;
	int16_t accy = 0;
	int16_t accz = 0;
	int16_t X;
	int16_t Y;
	int16_t Z;
	int num = 0;
	char value[80];
	for (int i = 0;i <= 5;i++)
	{
		num = (0x28+i);
		Accel_I2C_Write(num,2,0);
		arr[i] = Accel_I2C_Read(2);	
	}
/*	for (int i = 0;i <= 2;i++)
	{
		int n = i*2;
		accx = ((arr[n]<<8) |  (arr[n+1] & 0xFF));
	}*/

	nXlow = arr[0];
	nXhi  = arr[1];
	nYlow = arr[2];
	nYhi  = arr[3];
	nZlow = arr[4];
	nZhi  = arr[5];
	accx = ((nXhi << 8) | (nXlow & 0xFF));
	accy = ((nYhi << 8) | (nYlow & 0xFF));
	accz = ((nZhi << 8) | (nZlow & 0xFF));
	X = accx >> 8;
	Y = accy >> 8;
	Z = accz >> 8;
	//char acc[] = {X,Y,Z};
	
	/*for (int j = 0; j <= 2; j++)
	{
		I2C_Write(2,acc[j]);
		rgUnion->Write_Address++;
	}*/

	//PrintUARTstring("X=");
	sprintf(value, "%.2f",(double)X/32);
	//rgSystems->X_axis = value;
	PrintUARTstring(value);
	PrintUARTstring(",");
	sprintf(value, "%.2f", (double)Y/32);
	PrintUARTstring(value);
	PrintUARTstring(",");
	sprintf(value, "%.2f",(double)Z/32);
	PrintUARTstring(value);
	PrintUARTstring("\r\n");
	//_delay_ms(1000);
	
}

void Poll_State(void)
{	switch(rgSystems->current_state)
	{
		case Service:
			// Uart controll
			if(rgSystems->next_state==Idle)
			{	Initialize_Accel();
				
				Initiate_Logger();
				rgSystems->minute=0;		// viktig � starte timeren p� 0
				Clear_Data();
				rgSystems->Logging_count=0;
				Setup_timer();	//Start timer tA P� IGJEN SENERE
				INT_PIN_ENABLE(); //start int
				
				rgSystems->current_state = Idle;
				rgSystems->next_state= '\0';
				break;
			}
			if (rgUnion->Write_Address == 0xFFFF)
			{
				rgUnion->Write_Address = 0;
			}
			if ((rgUnion->Write_Address > 0x7FFF) && (rgUnion->Write_Address < 0xFFFF))
			{
				rgUnion->Write_Address = 0x7FFF;
				
			}
			else
			{	
				//Read uart
			}
			
			break;
			
		case Idle:
			//sleep
			if (rgSystems->next_state==Service)
			{	PrintUARTstring("Service:Active");//welcome message accordingly
				PrintUARTstring("\r\n");	
				TWI_Master_Initialise();	//reinit TWI
				Timer_Stop();//disble timer
				INT_PIN_DISABLE();//disable interrupt
				
				
				
				//LED1 on
				//welcome message
				rgSystems->current_state = Service;
				rgSystems->next_state= '\0';
				break;
			}
			if (rgSystems->next_state==Logging)
			{	
				INT_PIN_DISABLE();//disable interrupt
				TWI_Master_Initialise();	//reinit TWI
				rgSystems->current_state = Logging;
				rgSystems->next_state= '\0';
				break;
			}
			else
			{
				
				// wake up
				//sleep for x seconds

				set_sleep_mode(SLEEP_MODE_PWR_SAVE);
				sleep_enable();
				
				sleep_cpu();
				sleep_mode();                  //wake up 
				sleep_disable();
				
				//rgSystems->current_state = Sleep;
				break;
			}
		case Logging:
			//logging mode
			if (rgUnion->Write_Address < 0x10)
			{
				rgUnion->Write_Address = 0x10;
				Logg_Mesurement();
				Update_Intervall_Count();//oppdater intervall count
				Update_Index();//oppdater index
				INT_PIN_ENABLE();//reactiver pin int
				rgSystems->current_state= Idle;
				rgSystems->next_state= '\0';
				break;
			}
			if ((rgUnion->Write_Address > 0x7FFF) && (rgUnion->Write_Address < 0xFFFF))
			{
				rgUnion->Write_Address = 0x7FFF;
				Timer_Stop();	//disable timer but not INT pin
				// send into idle and forever sleep until pin int
				rgSystems->current_state= Idle;
				rgSystems->next_state= '\0';
				break;
			} else
			{
				Logg_Mesurement();
				Update_Intervall_Count();//oppdater intervall count
				Update_Index();//oppdater index
				INT_PIN_ENABLE();//reactiver pin int
				rgSystems->current_state= Idle;
				rgSystems->next_state= '\0';
				break;
			}

		
    }
}


void Power_Reduction(void)
{	
	power_adc_disable();	//Disable the Analog to Digital Converter module.
	power_timer0_disable();	//Disable the Timer 0 module.
	power_timer1_disable();	//Disable the Timer 1 module.
	power_spi_disable();	//Disable the Serial Peripheral Interface module.
}
int main( void )
{	Power_Reduction();
	Initialize_System();
	RXTX_Setup();
	unsigned char pressedButton,temp=0;
	//DDRB  = 0xFF;
	//DDRD  = 0x00;
	DDRD |= (0<<PD3);
	//DDRA = 0x00;
	TWI_Master_Initialise();
	sei();
	//ClearString(InputStr, sizeof(InputStr));
	if(Check_Initialized_System()==1)	//check settings(Initiate, logg count, 
		{
			rgSystems->initialzed=1;
						
		}
		else
		{
			Set_Default_Settings();
			PrintUARTstring("System:Initialized to Default");//welcome message accordingly
			PrintUARTstring("\r\n");
			rgSystems->initialzed=1;	
		}
	
	Initialize_Accel();
	
	
  for(;;)
  { 
		Poll_State();
	
	
	if(USARTHasData())
	{
		input_char = toupper(GetChar());
		USARTWriteChar(input_char); // echo back

		if(input_char == '\r')
		{
				PrintUARTstring("\r\n");
				if((strncmp(InputStr, "PRINT",5) == 0)||(strncmp(InputStr, "LOG",3) == 0)
				|| (strncmp(InputStr, "MEMORY",5) == 0)||(strncmp(InputStr, "START",4) == 0)||(strncmp(InputStr, "DATE",4) == 0)
				||(strncmp(InputStr, "CLEAR",5) == 0)||(strncmp(InputStr, "ACCEL",5) == 0)||(strncmp(InputStr, "TEMP",4) == 0)
				||(strncmp(InputStr, "TRESHOLD",8) == 0))
				{
					Parse_String(InputStr);
					ClearString(InputStr, sizeof(InputStr));
				}
				else
				{
					PrintUARTstring("400 ERROR\r\n");
					ClearString(InputStr, sizeof(InputStr));
					input_str_len = 0;
					input_char = 0;//nytt
					InputStr[input_str_len--] = input_char;//nytt
				}
			
		}
		if (input_char == '\b'||input_char == '|')
		{
			if (input_char == '\b')
			{
				input_char = 0;
				InputStr[input_str_len--] = 0;
				USARTWriteChar(' '); // echo back
				USARTWriteChar('\b'); // echo back
				if(input_str_len <= 0)
				{
					input_str_len = 0;
				}
			}
			if (input_char == '|')
			{
				for (int s = 0;s <= input_str_len;s++)
				{
					USARTWriteChar('\b');
					USARTWriteChar(' ');
					USARTWriteChar('\b'); // echo back
				}
				ClearString(InputStr, sizeof(InputStr));
				input_str_len = 0;
			}
		}
		else if(input_char != ('\b'||'|' ||'\r'))
		{
			InputStr[input_str_len++] = input_char;
		}
	}
		
   

  }

}


void Parse_String(char *InputStr)
{		
	
		if (strncmp(InputStr, "LOG",3) == 0) // set logging interval
		{	PrintUARTstring("200 OK\r\n");
			int interval=0;
			sscanf(InputStr,"%*[^0123456789]%d",&interval);
			rgSystems->Logging_Interval=interval;		//trenger bare endre globalt
		}
		if (strncmp(InputStr, "MEMORY",5) == 0) // Stores what address location was written to last soo I can calculate how much space is left
		{	PrintUARTstring("200 OK\r\n");
			 //FINN ut av hvor mye plass det er igjen
		}
		if ((strncmp(InputStr, "TRESHOLD",5) == 0))
		{
			Set_Ths(InputStr);
		}
		if (strncmp(InputStr, "DATE",4) == 0)
		{	PrintUARTstring("200 OK\r\n");
			Set_Date(InputStr);
		}
		if (strncmp(InputStr, "CLEAR",5) == 0)
		{	PrintUARTstring("200 OK\r\n");
			Clear_Data();
		}
		
		if (strncmp(InputStr, "START",4) == 0)
		{	PrintUARTstring("200 OK\r\n");
			//Power_Reduction();
			rgSystems->next_state=Idle;
			ClearString(InputStr, sizeof(InputStr));
				input_str_len = 0;
		}
		if (strcmp(InputStr, "ACCEL") == 0)
		{	PrintUARTstring("200 OK\r\n");
			Get_XYZ();
			
		}
		if (strcmp(InputStr, "ACCEL CONT") == 0)
		{	PrintUARTstring("200 OK\r\n");
			while (GetChar()==0)
			{
				//Get_XYZ();
				Check_Angel();
			}	
		}
		if (strcmp(InputStr, "TEMP") == 0)
		{
			PrintUARTstring("200 OK\r\n");
			Initiate_HTU21D();
			Print_Temp_Humid();
		}
		if (strcmp(InputStr, "TEMP CONT") == 0)
		{	PrintUARTstring("200 OK\r\n");
			Initiate_HTU21D();
			while (GetChar()==0)
			{
				Print_Temp_Humid();
				_delay_ms(100);
			}	
		}
		if(strncmp(InputStr, "PRINT",5) == 0)
		{	
			Check_Start_Time();
			PrintUARTstring("\r\n");
			// finn lengden av loggen... log_count *3
			uint16_t length= (Check_Logg_Count()*3)-1;
			PrintUARTstring("\r\n");
			if (length>0x7FF0)
			{
				PrintUARTstring("TO SHORT/LONG LENGTH");
				PrintUARTstring("\r\n");
			}
			else
			{
				rgUnion->Write_Address=0x10;
				for(uint16_t i = 0;i <= length;i++)
				{
				Read_From_Fram();
				rgUnion->Write_Address++;
				}
			}		// huske p� � gj�re write adress til det den var igjen og derfor kanskje hente ut info fra fram
		ClearString(InputStr, sizeof(InputStr));
		input_str_len = 0;
		input_char = 0;//nytt
		InputStr[input_str_len--] = input_char;
		}
		else{
			ClearString(InputStr, sizeof(InputStr));
			input_str_len = 0;
			input_char = 0;//nytt
			InputStr[input_str_len--] = input_char;
		}
	
}



void PrintUARTstring(char *str)
{
	int i;
	for(i=0; i < strlen(str); i++)
	{
		USARTWriteChar(str[i]);
	}
	return;
}

void ClearString(char *str, int len)
{
	int i;
	for (i = 0; i < len; i++)	
	{
		str[i] = 0;
	}
}


int USARTHasData()//skjekker om det blir tastet inn noe i terminalen
{
	if (rxReadpos != rxWritepos)
	return 1;
	else
	return 0;
}

void USARTWriteChar(char data)
{
	while (!(UCSR0A & (1 << UDRE0)))//fortsetter s� lenge UDRE0 bit er p�
	{}

	//Now write the data to USART buffer
	UDR0 = data; //transmitting data
	return;
}
void RXTX_Setup(void) // setter opp Reciving og transmitting utifra databladet
{
	UBRR0H = (BRC >>8);
	UBRR0L = BRC;
	
	UCSR0B = (1<<RXEN0)|(1<<RXCIE0)|(1<<TXEN0)/*|(1<<TXCIE0)*/; //enables interrupt og mottak  eneble transmitting og Complete Interrupt Enable
	UCSR0C = (1<<UCSZ01)|(1<<UCSZ00);// stop bit 8
}

char GetChar(void) //henter data som skal leses
{
	char ret='\0'; // setter til 0 char
	
	if (rxReadpos != rxWritepos) //hvis det skrives noe i terminalen( da er ikke write= read)
	{
		ret = RxBuffer[rxReadpos]; // ret blir endret til  rxbuffer plaseringen til readpos
		rxReadpos++; //increment neste input
		//rxReadpos= (rxReadpos + 1)% RX_BUFFER_SIZE;
		if(rxReadpos >= RX_BUFFER_SIZE)  // ringbuffer
		{
			rxReadpos = 0;
			
			
		}
	}
	return ret;
}

ISR(USART0_RX_vect)// recieving interrupt
{
	RxBuffer[rxWritepos] = UDR0; // data kommer fra receiver
	
	rxWritepos++;
	
	
	//rxWritepos= (rxWritepos + 1)% RX_BUFFER_SIZE;
	if(rxWritepos >= RX_BUFFER_SIZE)
	{
		rxWritepos = 0;
		
	}
}



//TIMER kode:
ISR(TIMER2_COMPB_vect)
{	
	rgSystems->second=rgSystems->second+5;
	if (rgSystems->second == 60)        //keep track of time, date, month, and year
	{	
		rgSystems->minute++;
		rgSystems->second = 0;
		

		if (rgSystems->minute >= rgSystems->Logging_Interval)
		{	rgSystems->Logging_count++;
			rgSystems->next_state=Logging;
			rgSystems->minute = 0;
			
		}
	}

	//PORTB=~(((rgSystems->second&0x01)|rgSystems->minute<<1)|rgSystems->hour<<7);
}




void Setup_timer(void)//setter opp timer interrupt utifra databladet 
{
	TIMSK2 &= ~((1<<OCIE2B)||(1<<TOIE2)); /* 1. Disable the Timer/Counter2 interrupts by clearing OCIE2 and TOIE2. */
	//ASSR = (1<<EXCLK);	//set Timer/counter0 to be asynchronous from the CPU clock
	//with a second external clock (32,768kHz)driving it.
	ASSR |= (1<<AS2);
	TCNT2 = 0;	// clear TCNT2
	TCCR2A= (1<<WGM01) ;
	OCR2A=160; //=5 sec
	TCCR2B |=    (1<<CS22) | (1<<CS21)| (1<<CS20);    //prescaler 128=1 sec //(1<<CS21)|(1<<CS22) | (1<<CS20); //prescaler 1024=8sec 
	while ((ASSR & (1<<OCR2BUB)) ||ASSR & (1<<TCR2BUB));
	//while (ASSR & ((1<<TCN2UB)|(1<<OCR2BUB)|(1<<TCR2BUB)));
	TIFR2 |= (1<<OCF2B);
	TIMSK2 |= (1<<OCIE2B);
	
}

void Timer_Stop(void)
{
	TIMSK2 &= ~(1<<TOIE2);
}
void INT_PIN_DISABLE(void)
{
	EIMSK = 0<<INT2;					// Enable INT0
}

void INT_PIN_ENABLE(void)
{
	EIMSK = 1<<INT2;					// Enable INT0
	EICRB = 1<<ISC01;	// Trigger INT0 on falling edge
}
ISR(INT2_vect)
{
	rgSystems->next_state=Service;
	
}

