/*
 * Struct.h
 *
 * Created: 16.01.2019 19:19:32
 *  Author: Dell
 */ 


#ifndef STRUCT_H_
#define STRUCT_H_

#define Idle	1
#define Logging 2
#define Service	3


typedef struct tSystem
{
	unsigned char second;
	unsigned char minute;
	unsigned char hour;
	unsigned char date;
	unsigned char month;
	int Accle_Ths;
	int Address;
	uint16_t year;
	int initialzed;
	uint16_t Index;
	int current_state;
	int next_state;
	int Logging_Mode;
	int Logging_Interval;
	uint16_t Logging_count;
} TSystem;

                //Assign a var name to the Union 
typedef union u_type            //Setup a Union
{
	
	uint16_t Write_Address; //=tSystem.Address;
	
	
	unsigned char Write_Bytes[2];
	
}
temp;

#endif /* STRUCT_H_ */